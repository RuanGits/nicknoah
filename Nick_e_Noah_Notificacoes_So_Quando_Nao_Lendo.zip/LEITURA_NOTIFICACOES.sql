-- Nick & Noah: somente notificar quando o destinatário NÃO está lendo a conversa atual.
-- Seguro para dados existentes: não altera mensagens nem usuários.
CREATE TABLE IF NOT EXISTS public.chat_reading_state (
 user_id uuid NOT NULL REFERENCES public.chat_members(user_id) ON DELETE CASCADE,
 device_id uuid NOT NULL,
 is_reading boolean NOT NULL DEFAULT false,
 updated_at timestamptz NOT NULL DEFAULT now(),
 PRIMARY KEY (user_id, device_id)
);
CREATE INDEX IF NOT EXISTS chat_reading_state_active_idx ON public.chat_reading_state(user_id, updated_at) WHERE is_reading = true;
ALTER TABLE public.chat_reading_state ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "NickNoah reading status own devices" ON public.chat_reading_state;
CREATE POLICY "NickNoah reading status own devices" ON public.chat_reading_state
 FOR ALL TO authenticated
 USING (user_id = (SELECT auth.uid()) AND public.is_chat_member())
 WITH CHECK (user_id = (SELECT auth.uid()) AND public.is_chat_member());
GRANT SELECT, INSERT, UPDATE, DELETE ON public.chat_reading_state TO authenticated;
SELECT 'Pronto: estado de leitura para notificações' AS resultado;
