// Edge Function de Web Push para Nick & Noah — execute com JWT obrigatório.
import { createClient } from 'npm:@supabase/supabase-js@2';
import webpush from 'npm:web-push@3.6.7';

const cors={ 'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS'};
const respond=(body:object,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,'Content-Type':'application/json'}});
Deno.serve(async request=>{
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
 if(request.method!=='POST')return respond({error:'Método não permitido'},405);
 try{
  const jwt=request.headers.get('Authorization')?.replace(/^Bearer\s+/i,'');
  if(!jwt)return respond({error:'Login necessário'},401);
  const url=Deno.env.get('SUPABASE_URL')!,pubKey=Deno.env.get('SUPABASE_ANON_KEY')!,svcKey=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const auth=createClient(url,pubKey,{global:{headers:{Authorization:`Bearer ${jwt}`}},auth:{persistSession:false,autoRefreshToken:false}});
  const {data:{user},error:userError}=await auth.auth.getUser(jwt);
  if(userError||!user)return respond({error:'Usuário não autenticado'},401);
  const {messageId}=await request.json();
  if(!Number.isSafeInteger(messageId)||messageId<=0)return respond({error:'Mensagem inválida'},400);
  const admin=createClient(url,svcKey,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:msg,error:msgError}=await admin.from('messages').select('id,sender_id,content,media_type').eq('id',messageId).maybeSingle();
  if(msgError||!msg||msg.sender_id!==user.id)return respond({error:'Sem permissão'},403);
  const {data:member}=await admin.from('chat_members').select('user_id,display_name').eq('user_id',user.id).maybeSingle();
  if(!member)return respond({error:'Não é membro do chat'},403);
  const {data:receivers,error:receiversError}=await admin.from('chat_members').select('user_id').neq('user_id',user.id);
  if(receiversError)throw receiversError;
  // Notifica apenas quando o destinatário não está lendo as mensagens atuais.
  // Uma sessão só conta como leitura se estiver ativa, visível e próxima ao fim.
  const recipientIds=(receivers||[]).map(x=>x.user_id);
  if(recipientIds.length===0)return respond({ok:true,delivered:0});
  const {data:activeReaders,error:readingError}=await admin.from('chat_reading_state')
   .select('user_id').in('user_id',recipientIds).eq('is_reading',true)
   .gte('updated_at',new Date(Date.now()-25000).toISOString());
  if(readingError)throw readingError;
  const readingUsers=new Set((activeReaders||[]).map(x=>x.user_id));
  const shouldNotify=recipientIds.filter(id=>!readingUsers.has(id));
  if(shouldNotify.length===0)return respond({ok:true,suppressed:'recipient_reading'});
  // A checagem de id único impede spam via reenvio da mesma mensagem.
  const {error:onceError}=await admin.from('push_delivery_events').insert({message_id:messageId});
  if(onceError){if(onceError.code==='23505')return respond({ok:true,duplicate:true});throw onceError;}
  const pub=Deno.env.get('VAPID_PUBLIC_KEY'),priv=Deno.env.get('VAPID_PRIVATE_KEY'),subject=Deno.env.get('VAPID_SUBJECT');
  if(!pub||!priv||!subject)throw new Error('VAPID não configurado');
  webpush.setVapidDetails(subject,pub,priv);
  if(shouldNotify.length===0)return respond({ok:true,delivered:0});
  const {data:subscriptions,error:subsError}=await admin.from('push_subscriptions').select('endpoint,subscription').in('user_id',shouldNotify);
  if(subsError)throw subsError;
  let delivered=0;
  for(const row of subscriptions||[]){
   try{
    await webpush.sendNotification(row.subscription,JSON.stringify({title:'Nick & Noah 💗',body:msg.media_type?'Você recebeu uma nova mídia':((msg.content||'Nova mensagem').slice(0,120)),icon:'./icon-192.png',url:'./',tag:'nick-noah-'+messageId,from:member.display_name}),{TTL:60*60*24});delivered++;
   }catch(e){const status=(e as {statusCode?:number}).statusCode;if(status===404||status===410)await admin.from('push_subscriptions').delete().eq('endpoint',row.endpoint);else console.warn('Push falhou',status);}
  }
  return respond({ok:true,delivered});
 }catch(err){console.error(err);return respond({error:'Não foi possível entregar push'},500);}
});
