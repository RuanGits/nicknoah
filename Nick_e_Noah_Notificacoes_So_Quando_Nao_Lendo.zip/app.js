(() => {
'use strict';
const $=id=>document.getElementById(id);
const cfg=window.NICK_NOAH_CONFIG||{};
if(!/^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(cfg.supabaseUrl||'')||!cfg.supabaseKey||!window.supabase){$('login-notice').textContent='Não foi possível iniciar. Confira a conexão e a configuração do Supabase.';$('login-notice').classList.add('error');$('login-button').disabled=true;return;}
// Sessão só na memória: cada visita/reload pede e-mail e senha novamente.
const db=window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseKey,{auth:{persistSession:false,autoRefreshToken:true,detectSessionInUrl:false}});
let unreadBelow=0,emojiHistory={},myEmojiKey='';
// O estado de leitura é por dispositivo: estar online não significa estar lendo.
const readingDeviceId=crypto.randomUUID();
let readingTimer=null,lastChatInteraction=Date.now(),lastReadingState=null,readingUpdatePending=false;
function activelyReading(){return !!me && showing && !document.hidden && document.hasFocus() && isChatNearBottom() && Date.now()-lastChatInteraction<120000;}
async function updateReadingState(force=false){
 if(!me || readingUpdatePending)return;
 const active=activelyReading();
 if(!force && active===lastReadingState && !active)return;
 readingUpdatePending=true;
 try{const {error}=await db.from('chat_reading_state').upsert({user_id:me.id,device_id:readingDeviceId,is_reading:active,updated_at:new Date().toISOString()},{onConflict:'user_id,device_id'});
 if(error)console.warn('[NickNoah] Estado de leitura:',error.message);else lastReadingState=active;
 }catch(e){console.warn('[NickNoah] Estado de leitura indisponível',e);}finally{readingUpdatePending=false;}
}
function registerReadingInteraction(){lastChatInteraction=Date.now();updateReadingState();}

let me=null,myName='',messagesChannel=null,settingsChannel=null,statusTimer=null,pollTimer=null,recording=null,recordChunks=[],audioStream=null,recStart=0,installEvent=null,seenIds=new Set(),rows=new Map(),loading=false,firstLoad=true,groupImagePath=null,partnerId=null,showing=true,opening=false,typingChannel=null,typingTimer=null,typingLastSent=0,replyTo=null,soundReady=false,audioContext=null,pastedImage=null,pastedImageUrl=null,avatarRequest=0; 
const fmtTime=v=>new Intl.DateTimeFormat('pt-BR',{hour:'2-digit',minute:'2-digit'}).format(new Date(v));
const fmtDate=v=>new Intl.DateTimeFormat('pt-BR',{day:'2-digit',month:'long',year:'numeric'}).format(new Date(v));
function banner(s){$('banner').textContent=s;$('banner').classList.toggle('hidden',!s)}
function loginNotice(s){$('login-notice').textContent=s;$('login-notice').classList.toggle('error',!!s)}
function loginView(){showing=false;$('chat-view').classList.add('hidden');$('login-view').classList.remove('hidden');}
function chatView(){showing=true;$('login-view').classList.add('hidden');$('chat-view').classList.remove('hidden');$('whoami').textContent=myName;}
function closeChannels(){if(readingTimer){clearInterval(readingTimer);readingTimer=null;} if(messagesChannel)db.removeChannel(messagesChannel);if(settingsChannel)db.removeChannel(settingsChannel);if(typingChannel)db.removeChannel(typingChannel);typingChannel=null;if(typingTimer)clearTimeout(typingTimer);typingTimer=null;messagesChannel=settingsChannel=null;if(statusTimer)clearInterval(statusTimer);if(pollTimer)clearInterval(pollTimer);statusTimer=pollTimer=null;}
function reset(){lastReadingState=null; if(recording&&recording.state!=='inactive'){voiceAction='cancel';recording.stop();}if(typeof clearVoiceUI==='function')clearVoiceUI();closeChannels();me=null;partnerId=null;myName='';seenIds.clear();rows.clear();firstLoad=true;replyTo=null;hideReply();hideTyping();clearPastedImage();$('message-list').replaceChildren();pushConfigured=false;unreadBelow=0;emojiHistory={};myEmojiKey='';updateJumpButton();$('message-list').dataset.day='';groupImagePath=null;avatarRequest++;$('group-avatar').replaceChildren(document.createTextNode('♡'));$('partner-status').textContent='';$('message-input').value='';}
async function signed(path){if(!path)return null;const {data,error}=await db.storage.from('chat-media').createSignedUrl(path,3600);if(error)throw error;return data.signedUrl;}
async function showGroupPhoto(path){
 const node=$('group-avatar');
 if(path===groupImagePath && ((path && node.querySelector('img')) || (!path && !node.querySelector('img')))) return;
 groupImagePath=path;
 const request=++avatarRequest;
 if(!path){node.replaceChildren(document.createTextNode('♡'));return;}
 try{
   const url=await signed(path);
   if(request!==avatarRequest || groupImagePath!==path)return;
   const img=new Image();img.alt='Foto do grupo';img.decoding='async';img.src=url;
   await new Promise((resolve,reject)=>{if(img.complete && img.naturalWidth){resolve();return;}img.onload=resolve;img.onerror=reject;});
   if(request!==avatarRequest || groupImagePath!==path)return;
   node.replaceChildren(img);
 }catch{ if(request===avatarRequest&&!node.querySelector('img'))node.textContent='♡'; }
}
async function loadGroup(){const {data,error}=await db.from('chat_settings').select('group_photo_path').eq('id',1).single();if(error)throw error;await showGroupPhoto(data.group_photo_path);}
async function uploadFile(file,kind='chat'){
 const isImage=file.type.startsWith('image/'),isAudio=file.type.startsWith('audio/'),isVideo=file.type.startsWith('video/');
 if(!isImage&&!isAudio&&!isVideo)throw Error('Só são permitidas fotos, áudios e vídeos.');
 if(file.size>64*1024*1024)throw Error('Arquivo maior que 64 MB.');
 if(file.size===0)throw Error('Arquivo vazio.');
 const clean=(file.name||'arquivo').split('.').pop().toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
 const path=me.id+'/'+crypto.randomUUID()+'.'+clean;
 // upload padrão, sujeito ao limite do plano Supabase; para maior confiabilidade >6MB usar TUS no futuro.
 const {error}=await db.storage.from('chat-media').upload(path,file,{contentType:file.type,upsert:false,cacheControl:'3600'});
 if(error){if(file.size>50*1024*1024)throw Error('O plano gratuito do Supabase limita arquivos a 50 MB. Atualize o plano/configuração para enviar até 64 MB.');throw error;}
 return {path,type:isImage?'image':isAudio?'audio':'video'};
}
function formatDuration(seconds){if(!Number.isFinite(seconds)||seconds<0)return '00:00';const s=Math.floor(seconds);return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
function openImageViewer(url){$('image-viewer-image').src=url;$('image-viewer-download').href=url;$('image-viewer').classList.remove('hidden');document.body.style.overflow='hidden';}
function closeImageViewer(){$('image-viewer').classList.add('hidden');$('image-viewer-image').removeAttribute('src');document.body.style.overflow='';}
$('image-viewer-close').addEventListener('click',closeImageViewer);
$('image-viewer').addEventListener('click',e=>{if(e.target===$('image-viewer'))closeImageViewer();});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeImageViewer();});
function buildAudioPlayer(target,url){
 const media=document.createElement('audio');media.preload='metadata';media.src=url;
 const title=document.createElement('div');title.className='audio-title';title.textContent='🎙 Mensagem de voz';target.append(title);
 const controls=document.createElement('div');controls.className='pretty-audio-controls';
 const play=document.createElement('button');play.type='button';play.className='pretty-audio-play';play.textContent='▶';play.setAttribute('aria-label','Reproduzir áudio');
 const range=document.createElement('input');range.type='range';range.min='0';range.max='1000';range.value='0';range.className='pretty-audio-progress';range.setAttribute('aria-label','Progresso do áudio');
 const clock=document.createElement('span');clock.className='pretty-audio-time';clock.textContent='00:00 / --:--';
 controls.append(play,range,clock);target.append(controls,media);
 let knownDuration=0,checkingDuration=false;
 function validDuration(){return Number.isFinite(media.duration)&&media.duration>0?media.duration:knownDuration;}
 function redraw(){const d=validDuration();if(d>0)knownDuration=d;range.value=d>0?String(Math.round(Math.min(1,media.currentTime/d)*1000)):'0';clock.textContent=formatDuration(media.currentTime)+' / '+(d>0?formatDuration(d):'--:--');}
 function recoverWebmDuration(){
   if(checkingDuration||knownDuration||Number.isFinite(media.duration))return;
   checkingDuration=true;
   // Alguns áudios gravados pelo Chrome chegam com duração Infinity.
   // Buscar o fim do arquivo força o navegador a calcular a duração real.
   media.currentTime=1e9;
 }
 media.addEventListener('loadedmetadata',()=>{if(Number.isFinite(media.duration)&&media.duration>0)knownDuration=media.duration;else recoverWebmDuration();redraw();});
 media.addEventListener('durationchange',()=>{if(Number.isFinite(media.duration)&&media.duration>0){knownDuration=media.duration;if(checkingDuration){checkingDuration=false;media.currentTime=0;}}redraw();});
 media.addEventListener('seeked',()=>{if(checkingDuration){if(Number.isFinite(media.currentTime)&&media.currentTime>0)knownDuration=media.currentTime;checkingDuration=false;media.currentTime=0;}redraw();});
 media.addEventListener('timeupdate',redraw);
 play.onclick=async()=>{try{if(media.paused){await media.play();}else media.pause();}catch{clock.textContent='Áudio indisponível';}};
 media.onplay=()=>{play.textContent='Ⅱ';play.setAttribute('aria-label','Pausar áudio');};
 media.onpause=()=>{play.textContent='▶';play.setAttribute('aria-label','Reproduzir áudio');};
 media.onended=()=>{play.textContent='▶';media.currentTime=0;redraw();};
 range.oninput=()=>{const d=validDuration();if(d>0)media.currentTime=Number(range.value)/1000*d;};
}
function attachMedia(container,item){
 const el=document.createElement('div');el.className='attachment-block';container.append(el);
 const waiting=document.createElement('span');waiting.textContent='Carregando mídia...';el.append(waiting);
 signed(item.media_path).then(url=>{
   el.replaceChildren();
   if(item.media_type==='image'){
     const img=document.createElement('img');img.className='media-preview image-inline';img.alt='Foto enviada — toque para ampliar';img.loading='lazy';img.src=url;img.tabIndex=0;img.onclick=()=>openImageViewer(url);img.onkeydown=e=>{if(e.key==='Enter')openImageViewer(url);};el.append(img);
   }else if(item.media_type==='audio'){
     el.classList.add('audio-attachment');buildAudioPlayer(el,url);
   }else{
     const video=document.createElement('video');video.controls=true;video.preload='metadata';video.className='media-preview video-preview';video.src=url;el.append(video);
   }
   const dl=document.createElement('a');dl.href=url;dl.target='_blank';dl.rel='noopener noreferrer';dl.download=(item.media_type==='audio'?'audio':item.media_type==='image'?'foto':'video')+'-nick-noah';dl.className='download-media';dl.textContent=item.media_type==='audio'?'↓ Baixar áudio':'↓ Baixar mídia';
   dl.addEventListener('click',async e=>{
     e.preventDefault();
     try{
       const response=await fetch(url);
       if(!response.ok)throw Error('Download indisponível');
       const blob=await response.blob();const tmp=URL.createObjectURL(blob);
       const a=document.createElement('a');a.href=tmp;a.download=(item.media_type==='audio'?'audio':item.media_type==='image'?'foto':'video')+'-nick-noah.'+(item.media_path.split('.').pop()||'bin');
       document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(tmp),3000);
     }catch{window.open(url,'_blank','noopener,noreferrer');}
   });
   el.append(dl);
 }).catch(()=>waiting.textContent='Mídia indisponível. Verifique as permissões do Storage.');
}
function syncRead(item){const meta=document.querySelector('[data-id="'+item.id+'"] .meta');if(!meta||!me||item.sender_id!==me.id)return;meta.replaceChildren(document.createTextNode(fmtTime(item.created_at)+' · '));const ticks=document.createElement('span');ticks.className='read-ticks'+(item.read_at?' is-read':'');ticks.textContent=item.read_at?'✓✓':'✓';ticks.title=item.read_at?'Lida':'Enviada';meta.append(ticks);}
function setReply(item){replyTo=item;const author=item.sender_id===me?.id?'Você':(myName==='Nick'?'Noah':'Nick');$('reply-author').textContent='Respondendo a '+author;$('reply-preview').textContent=(item.content||({'audio':'🎙 Áudio','image':'📷 Foto','video':'🎥 Vídeo'}[item.media_type]||'Mensagem')).slice(0,115);$('reply-box').classList.remove('hidden');$('message-input').focus();}
function hideReply(){const box=$('reply-box');if(box)box.classList.add('hidden');}
function hideTyping(){const el=$('typing-indicator');if(el)el.classList.add('hidden');}
function showTyping(){const el=$('typing-indicator');if(!el)return;el.classList.remove('hidden');if(typingTimer)clearTimeout(typingTimer);typingTimer=setTimeout(hideTyping,2500);}
function sendTyping(active=true){if(!typingChannel||!me)return;const now=Date.now();if(active&&now-typingLastSent<900)return;typingLastSent=now;typingChannel.send({type:'broadcast',event:'typing',payload:{sender:me.id,active}}).catch(()=>{});}
function unlockSound(){soundReady=true;try{audioContext=audioContext||new (window.AudioContext||window.webkitAudioContext)();if(audioContext.state==='suspended')audioContext.resume().catch(()=>{});}catch{}}
function plim(){if(!soundReady)return;try{const ctx=audioContext;if(!ctx)return;if(ctx.state==='suspended')ctx.resume().catch(()=>{});const t=ctx.currentTime;for(const [index,freq] of [830,1175].entries()){const osc=ctx.createOscillator(),gain=ctx.createGain();osc.type='sine';osc.frequency.value=freq;const at=t+index*.115;gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(.075,at+.012);gain.gain.exponentialRampToValueAtTime(.0001,at+.20);osc.connect(gain);gain.connect(ctx.destination);osc.start(at);osc.stop(at+.22);}}catch(e){console.debug('Plim indisponível',e);}}
function incomingNotification(item){if(!me||item.sender_id===me.id||firstLoad||activelyReading())return;plim();if(pushConfigured&&document.hidden)return;if(document.hidden||!document.hasFocus()){document.title='💗 Nova mensagem · Nick & Noah';try{if('Notification'in window&&Notification.permission==='granted'){const n=new Notification('Nick & Noah 💗',{body:item.media_path?'Você recebeu uma mídia!':(item.content||'Nova mensagem').slice(0,100),icon:'./icon-192.png',tag:'nick-noah-new-message'});n.onclick=()=>{window.focus();n.close();};}}catch(e){console.debug('Notificação indisponível',e);}}}
$('reply-cancel').addEventListener('click',()=>{replyTo=null;hideReply();});
$('message-input').addEventListener('focus',unlockSound);
document.addEventListener('pointerdown',unlockSound,{once:true});
function dayHeader(day){const d=document.createElement('div');d.className='day';const b=document.createElement('span');b.textContent=day;d.append(b);$('message-list').append(d);}
function message(item,scroll=true){if(!me||seenIds.has(item.id))return;const shouldFollow=scroll&&isChatNearBottom();seenIds.add(item.id);rows.set(item.id,item);const mine=item.sender_id===me.id;
 const last=$('message-list').dataset.day||'';const day=fmtDate(item.created_at);if(last!==day){dayHeader(day);$('message-list').dataset.day=day;}
 const row=document.createElement('div');row.className='msg-row'+(!firstLoad?' animate-msg':'')+(mine?' mine':'');row.dataset.id=item.id;
 const bubble=document.createElement('div');bubble.className='bubble';if(item.reply_to_id){const quoted=document.createElement('div');quoted.className='quoted-message';const original=rows.get(item.reply_to_id);quoted.textContent=original?(original.content||({'audio':'🎙 Áudio','image':'📷 Foto','video':'🎥 Vídeo'}[original.media_type]||'Mensagem')):'↩ Mensagem respondida';quoted.title='Mensagem respondida';bubble.append(quoted);}if(item.content){const body=document.createElement('div');body.textContent=item.content;bubble.append(body);}if(item.media_path)attachMedia(bubble,item);
 const meta=document.createElement('div');meta.className='meta';meta.textContent=fmtTime(item.created_at);bubble.append(meta);const replyBtn=document.createElement('button');replyBtn.type='button';replyBtn.className='reply-action';replyBtn.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M9 10 4 14l5 4"/><path d="M4 14h10c4 0 6-2 6-6"/></svg>'; replyBtn.title='Responder a esta mensagem';replyBtn.setAttribute('aria-label','Responder mensagem');replyBtn.onclick=()=>setReply(rows.get(item.id)||item);row.append(bubble,replyBtn);
 if(mine){const del=document.createElement('button');del.type='button';del.className='delete-action';del.textContent='✕';del.title='Apagar minha mensagem';del.setAttribute('aria-label','Apagar mensagem');del.onclick=()=>deleteMessage(item.id);row.append(del);}
 $('message-list').append(row);if(mine)syncRead(item);
 if(shouldFollow)scrollChatToBottom();else {if(!firstLoad&&!mine&&scroll)unreadBelow++;updateJumpButton();}
 if(!mine)incomingNotification(item);
 if(!mine&&activelyReading())markRead();
}
async function markRead(){if(!activelyReading())return;const {error}=await db.from('messages').update({read_at:new Date().toISOString()}).neq('sender_id',me.id).is('read_at',null);if(error)console.warn('read receipts',error.message);}
function isChatNearBottom(){const el=$('messages');return el.scrollHeight-el.scrollTop-el.clientHeight<100;}
function scrollChatToBottom(){const el=$('messages');el.scrollTop=el.scrollHeight;unreadBelow=0;updateJumpButton();registerReadingInteraction();if(activelyReading())markRead();}
function updateJumpButton(){const el=$('messages');const away=el.scrollHeight-el.scrollTop-el.clientHeight>=125;const btn=$('jump-latest');btn.classList.toggle('hidden',!away);if(!away)unreadBelow=0;const badge=$('jump-unread');badge.textContent=unreadBelow>99?'99+':String(unreadBelow);badge.classList.toggle('hidden',unreadBelow===0);btn.setAttribute('aria-label',unreadBelow?`${unreadBelow} mensagens novas. Ir para o final`:'Ir para as mensagens recentes');}
$('messages').addEventListener('scroll',()=>{updateJumpButton();registerReadingInteraction();if(activelyReading())markRead();},{passive:true});
$('jump-latest').addEventListener('click',()=>scrollChatToBottom());
function removeMessage(id){const row=document.querySelector('[data-id="'+id+'"]');if(row)row.remove();seenIds.delete(id);rows.delete(id);updateJumpButton();}
async function deleteMessage(id){if(!me)return;const item=rows.get(id);if(!item||item.sender_id!==me.id||!confirm('Apagar esta mensagem para os dois?'))return;
 const {error}=await db.from('messages').delete().eq('id',id).eq('sender_id',me.id);if(error){banner('Não foi possível apagar: '+error.message);return;}removeMessage(id);}

async function loadMessages(){if(!me||loading)return;loading=true;const stickToBottom=firstLoad||isChatNearBottom();try{const {data,error}=await db.from('messages').select('id,sender_id,content,media_path,media_type,read_at,reply_to_id,created_at').order('id',{ascending:false}).limit(200);if(error)throw error;const sorted=[...(data||[])].reverse();for(const item of sorted){if(rows.has(item.id)){const old=rows.get(item.id);if(item.read_at&&!old.read_at){old.read_at=item.read_at;const meta=document.querySelector('[data-id="'+item.id+'"] .meta');if(meta&&item.sender_id===me.id)syncRead(old);}continue;}if(!firstLoad&&!stickToBottom&&item.sender_id!==me.id)unreadBelow++;message(item,false);}if(firstLoad)firstLoad=false;if(stickToBottom)scrollChatToBottom();else updateJumpButton();if(activelyReading())await markRead();banner('');}catch(e){console.error(e);banner('Não foi possível carregar as mensagens. Rode o arquivo ATUALIZACAO.sql no Supabase.')}finally{loading=false;}}
async function setPresence(online=true){if(!me)return;await db.from('chat_presence').upsert({user_id:me.id,last_seen:new Date().toISOString(),is_online:online},{onConflict:'user_id'});}
async function loadPresence(){if(!me)return;const {data,error}=await db.from('chat_presence').select('user_id,is_online,last_seen');if(error)return;const them=(data||[]).find(p=>p.user_id!==me.id);const label=$('partner-status');if(!them){label.textContent='Aguardando a outra pessoa entrar';return;}partnerId=them.user_id;const ms=Date.now()-new Date(them.last_seen).getTime();const online=them.is_online&&ms<50000;label.textContent=online?'● Online agora':'Visto por último: '+new Intl.DateTimeFormat('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(them.last_seen));label.style.color=online?'#81e9ab':'#d4a9c2';}
async function openChat(user){if(opening)return;opening=true;try{reset();me=user;const {data,error}=await db.from('chat_members').select('display_name').eq('user_id',user.id).single();if(error||!data){await db.auth.signOut();reset();loginView();loginNotice('Este e-mail não está autorizado.');return;}myName=data.display_name;loadEmojiHistory();chatView();lastChatInteraction=Date.now();readingTimer=setInterval(()=>updateReadingState(true),8000);await Promise.allSettled([loadGroup(),loadMessages(),setPresence(true),loadPresence()]);initPush();updateReadingState(true);
 messagesChannel=db.channel('nick-noah-v2-messages').on('postgres_changes',{event:'INSERT',schema:'public',table:'messages'},({new:r})=>{if(!me)return;if(r.sender_id===me.id&&pendingOwnSends>0)return;message(r);}).on('postgres_changes',{event:'UPDATE',schema:'public',table:'messages'},({new:r})=>{if(!me)return;const old=rows.get(r.id);if(old&&r.read_at&&!old.read_at){old.read_at=r.read_at;const meta=document.querySelector('[data-id="'+r.id+'"] .meta');if(meta&&r.sender_id===me.id)syncRead(old);}}).on('postgres_changes',{event:'DELETE',schema:'public',table:'messages'},({old:r})=>{if(r?.id)removeMessage(r.id);}).subscribe(v=>{$('connection-status').textContent=v==='SUBSCRIBED'?'Conectado':'Reconectando...';$('status-dot').classList.toggle('live',v==='SUBSCRIBED');});
 typingChannel=db.channel('nick-noah-typing',{config:{broadcast:{self:false}}}).on('broadcast',{event:'typing'},({payload})=>{if(payload?.sender===me?.id)return;if(payload?.active)showTyping();else hideTyping();}).subscribe();
 settingsChannel=db.channel('nick-noah-v2-settings').on('postgres_changes',{event:'UPDATE',schema:'public',table:'chat_settings'},({new:r})=>{showGroupPhoto(r.group_photo_path);}).subscribe();
 statusTimer=setInterval(()=>{if(me){setPresence(document.visibilityState==='visible');loadPresence();}},15000);pollTimer=setInterval(()=>{if(me){loadMessages();loadGroup();}},12000);
 }catch(e){banner('Falha ao iniciar: '+e.message);}finally{opening=false;}}
$('login-form').addEventListener('submit',async e=>{e.preventDefault();const btn=$('login-button');btn.disabled=true;loginNotice('Entrando...');try{const {data,error}=await db.auth.signInWithPassword({email:$('email').value.trim(),password:$('password').value});if(error)throw error;$('password').value='';await openChat(data.user);}catch(e){loginNotice('E-mail ou senha incorretos, ou acesso não autorizado.');}finally{btn.disabled=false;}});
$('logout').addEventListener('click',async()=>{if(me)await db.from('chat_reading_state').delete().eq('user_id',me.id).eq('device_id',readingDeviceId).then(()=>{},()=>{});await setPresence(false);await db.auth.signOut();reset();loginView();$('password').value='';loginNotice('Somente Nick e Noah podem acessar.');});
let pendingOwnSends=0;
async function sendMessage(content,media=null){if(!me)return;const payload={sender_id:me.id,content:content||'',media_path:media?.path||null,media_type:media?.type||null,reply_to_id:replyTo?.id||null};
 let tempId=null;if(!media){tempId='temp-'+Date.now()+'-'+Math.random().toString(36).slice(2);message({...payload,id:tempId,created_at:new Date().toISOString(),read_at:null});document.querySelector('[data-id="'+tempId+'"]')?.classList.add('pending');}
 pendingOwnSends++;
 try{const {data,error}=await db.from('messages').insert(payload).select('id,sender_id,content,media_path,media_type,read_at,reply_to_id,created_at').single();if(error)throw error;
 if(tempId){const row=document.querySelector('[data-id="'+tempId+'"]');seenIds.delete(tempId);rows.delete(tempId);seenIds.add(data.id);rows.set(data.id,data);if(row){row.dataset.id=data.id;row.classList.remove('pending');row.querySelector('.meta')?.replaceChildren(document.createTextNode(fmtTime(data.created_at)));row.querySelector('.reply-action').onclick=()=>setReply(rows.get(data.id));const del=row.querySelector('.delete-action');if(del)del.onclick=()=>deleteMessage(data.id);syncRead(data);}else message(data);}else message(data);
 replyTo=null;hideReply();sendTyping(false);
 // Push depende da inscrição do DESTINATÁRIO, não do remetente.
 db.functions.invoke('nick-noah-push',{body:{messageId:data.id}}).then(({data:result,error:pushError})=>{if(pushError)console.warn('[NickNoah Push] Falha na Edge Function:',pushError);else console.info('[NickNoah Push] Resultado:',result);}).catch(e=>console.warn('[NickNoah Push] Falha de rede:',e));
 return data;
 }catch(error){if(tempId){const row=document.querySelector('[data-id="'+tempId+'"]');if(row){row.classList.remove('pending');row.classList.add('send-failed');}setTimeout(()=>removeMessage(tempId),7000);}throw error;}finally{pendingOwnSends--;}}

function clearPastedImage(){pastedImage=null;if(pastedImageUrl){URL.revokeObjectURL(pastedImageUrl);pastedImageUrl=null;}$('paste-preview')?.classList.add('hidden');const img=$('paste-preview-image');if(img)img.removeAttribute('src');}
$('paste-cancel').addEventListener('click',clearPastedImage);
$('message-input').addEventListener('paste',e=>{
 const items=Array.from(e.clipboardData?.items||[]);
 const img=items.find(item=>item.kind==='file'&&item.type.startsWith('image/'));
 if(!img||!me)return;
 const file=img.getAsFile();if(!file)return;
 e.preventDefault();
 clearPastedImage();
 pastedImage=new File([file],'imagem-colada-'+Date.now()+'.'+(file.type==='image/png'?'png':file.type==='image/gif'?'gif':'jpg'),{type:file.type});
 pastedImageUrl=URL.createObjectURL(pastedImage);
 $('paste-preview-image').src=pastedImageUrl;$('paste-preview').classList.remove('hidden');
});
$('message-form').addEventListener('submit',async e=>{
 e.preventDefault();const input=$('message-input'),val=input.value.trim(),image=pastedImage;
 if((!val&&!image)||!me)return;
 const btn=$('send-button');btn.disabled=true;
 const inputOriginal=val;const originalReply=replyTo;let clearImmediately=!image;
 if(clearImmediately){input.value='';input.style.height='auto';$('emoji-panel').classList.add('hidden');scrollChatToBottom();}
 try{
   let uploaded=null;
   if(image){$('file-status').classList.remove('hidden');$('file-status').textContent='Enviando imagem colada...';uploaded=await uploadFile(image);}
   await sendMessage(val,uploaded);
   if(!clearImmediately){input.value='';input.style.height='auto';}clearPastedImage();
   $('file-status').classList.add('hidden');
   btn.classList.remove('sent-pop');void btn.offsetWidth;btn.classList.add('sent-pop');banner('');
 }catch(err){banner('Não foi possível enviar: '+err.message);$('file-status').classList.add('hidden');if(clearImmediately&&!input.value){input.value=inputOriginal;replyTo=originalReply;if(replyTo)setReply(replyTo);}}
 finally{btn.disabled=false;/* não roubar o foco do teclado */}
});
$('message-input').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.keyCode!==229){e.preventDefault();$('message-form').requestSubmit();}});
let lastSpark=0;function animateKey(val){const now=performance.now();if(now-lastSpark<110)return;lastSpark=now;const s=$('key-spark');s.textContent=val===' '? '♡' : val;if(s.animate)s.animate([{opacity:.85,transform:'translateY(9px) scale(.75)'},{opacity:0,transform:'translateY(-14px) scale(1.08)'}],{duration:240,easing:'ease-out'});}
let textareaResizeScheduled=false;
function scheduleTextareaResize(){if(textareaResizeScheduled)return;textareaResizeScheduled=true;requestAnimationFrame(()=>{textareaResizeScheduled=false;const el=$('message-input');el.style.height='auto';el.style.height=Math.min(el.scrollHeight,130)+'px';});}
$('message-input').addEventListener('input',e=>{const el=e.target;const panel=$('emoji-panel');if(!panel.classList.contains('hidden') && (e.inputType==='insertText'||e.inputType==='insertFromPaste'||e.inputType==='insertCompositionText') && e.data && /[\p{L}\p{N}]/u.test(e.data))panel.classList.add('hidden');scheduleTextareaResize();sendTyping(!!el.value.trim());if(!e.isComposing&&e.inputType==='insertText'&&e.data)animateKey(e.data.slice(-1));});
$('message-input').addEventListener('compositionend',()=>sendTyping(true));
$('attach').addEventListener('click',()=>$('attachment-input').click());
$('attachment-input').addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file||!me)return;$('file-status').classList.remove('hidden');$('file-status').textContent='Enviando '+file.name+' ('+(file.size/1024/1024).toFixed(1)+' MB)...';$('attach').disabled=true;try{const media=await uploadFile(file);await sendMessage('',media);$('file-status').textContent='Mídia enviada!';setTimeout(()=>$('file-status').classList.add('hidden'),2500);banner('');}catch(err){banner('Falha no envio: '+err.message);$('file-status').textContent='Falha no envio.';}finally{$('attach').disabled=false;e.target.value='';}});
const emojiGroups=window.NICK_NOAH_EMOJIS||{};
const EMOJI_RECENT='🕘 Recentes';
let emojiCategory=EMOJI_RECENT,emojiVisibleList=[],emojiOffset=0;
const emojiSearchTags={'❤️':'amor coração','🥰':'amor feliz','😂':'risada rindo','😭':'chorar triste','😍':'apaixonado','👍':'positivo','🔥':'fogo','💗':'coração rosa','😘':'beijo','🎉':'festa','✨':'brilho'};
function loadEmojiHistory(){myEmojiKey='nn-emojis-'+me.id;try{const data=JSON.parse(localStorage.getItem(myEmojiKey)||'{}');emojiHistory=(data&&typeof data==='object'&&!Array.isArray(data))?data:{};}catch{emojiHistory={};}}
function recentEmojis(){return Object.entries(emojiHistory).filter(([em,v])=>typeof em==='string'&&v&&Number.isFinite(v.count)&&v.count>0).sort((a,b)=>b[1].count-a[1].count||b[1].last-a[1].last).slice(0,90).map(([em])=>em);}
function trackEmoji(em){const item=emojiHistory[em]||{count:0,last:0};emojiHistory[em]={count:item.count+1,last:Date.now()};try{localStorage.setItem(myEmojiKey,JSON.stringify(emojiHistory));}catch{} }
function addEmoji(em){const el=$('message-input'),pos=el.selectionStart;el.setRangeText(em,pos,el.selectionEnd,'end');trackEmoji(em);el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertReplacementText',data:em}));/* Mantém o seletor aberto para escolher vários emojis. Não força o foco para fora da lista. */if(emojiCategory===EMOJI_RECENT){const posY=$('emoji-grid').scrollTop;renderEmojiGrid($('emoji-search').value);$('emoji-grid').scrollTop=posY;}}
function appendEmojiPage(){const grid=$('emoji-grid');if(emojiOffset>=emojiVisibleList.length)return;const frag=document.createDocumentFragment();for(const em of emojiVisibleList.slice(emojiOffset,emojiOffset+126)){const b=document.createElement('button');b.type='button';b.textContent=em;b.title='Inserir '+em;b.setAttribute('aria-label','Inserir emoji '+em);b.addEventListener('pointerdown',e=>e.preventDefault());b.addEventListener('click',()=>addEmoji(em));frag.append(b);}emojiOffset+=126;grid.append(frag);}
function renderEmojiGrid(search=''){const grid=$('emoji-grid');grid.replaceChildren();grid.scrollTop=0;emojiOffset=0;const input=search.trim().toLowerCase();const all=input?[...new Set(Object.values(emojiGroups).flat())]:emojiCategory===EMOJI_RECENT?recentEmojis():emojiGroups[emojiCategory]||[];emojiVisibleList=input?all.filter(e=>(emojiSearchTags[e]||'').includes(input)||e.includes(input)):all;if(!input&&emojiCategory===EMOJI_RECENT&&!all.length){const note=document.createElement('div');note.className='emoji-empty';note.textContent='Seus emojis mais usados aparecerão aqui conforme você os escolher 💗';grid.append(note);}appendEmojiPage();}
$('emoji-grid').addEventListener('scroll',()=>{const el=$('emoji-grid');if(el.scrollHeight-el.scrollTop-el.clientHeight<90)appendEmojiPage();},{passive:true});
for(const cat of [EMOJI_RECENT,...Object.keys(emojiGroups)]){const b=document.createElement('button');b.type='button';b.textContent=({'Carinhas':'😀','Pessoas':'🫶','Animais':'🐻','Comidas':'🍓','Viagens':'🚗','Objetos':'💡','Símbolos':'💗','Bandeiras':'🏳️'})[cat]||'🕘';b.title=cat;b.setAttribute('aria-label',cat);b.onclick=()=>{emojiCategory=cat;document.querySelectorAll('#emoji-tabs button').forEach(x=>x.classList.toggle('active',x===b));renderEmojiGrid($('emoji-search').value);};$('emoji-tabs').append(b);}
$('emoji-tabs').firstElementChild?.classList.add('active');
$('emoji-search').addEventListener('input',e=>renderEmojiGrid(e.target.value));
$('emoji-close').addEventListener('click',()=>$('emoji-panel').classList.add('hidden'));
$('emoji').addEventListener('click',()=>{const panel=$('emoji-panel');panel.classList.toggle('hidden');if(!panel.classList.contains('hidden')){renderEmojiGrid($('emoji-search').value);/* Não abrir teclado nem mudar foco: ideal para tocar vários emojis seguidos. */}});
const MIC_ICON='<svg aria-hidden="true" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 17v5m-4 0h8"/></svg>';
$('record').innerHTML=MIC_ICON;
// O áudio só é enviado quando o usuário toca em "Enviar áudio".
let voiceTimer=null,voiceBusy=false,voiceAction='cancel';
function updateVoiceTime(){const secs=Math.floor((Date.now()-recStart)/1000);$('voice-time').textContent=String(Math.floor(secs/60)).padStart(2,'0')+':'+String(secs%60).padStart(2,'0');}
function clearVoiceUI(){if(voiceTimer){clearInterval(voiceTimer);voiceTimer=null;}$('voice-recorder').classList.add('hidden');$('record').classList.remove('recording');$('record').innerHTML=MIC_ICON;$('record').setAttribute('aria-label','Gravar áudio');$('record').title='Gravar áudio';}
function finishVoice(action){if(!recording||recording.state==='inactive')return;voiceAction=action;clearVoiceUI();recording.stop();}
$('voice-cancel').addEventListener('click',()=>finishVoice('cancel'));
$('voice-send').addEventListener('click',()=>finishVoice('send'));
$('record').addEventListener('click',async()=>{
 if(recording||voiceBusy)return;
 if(!me){banner('Entre no chat para gravar áudio.');return;}
 if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){banner('Este navegador não permite gravação de áudio.');return;}
 voiceBusy=true;
 try{
   const stream=await navigator.mediaDevices.getUserMedia({audio:true});
   if(!me){stream.getTracks().forEach(t=>t.stop());return;}
   audioStream=stream;
   const preferred=['audio/webm;codecs=opus','audio/mp4','audio/webm'].find(t=>MediaRecorder.isTypeSupported(t));
   const recorder=new MediaRecorder(stream,preferred?{mimeType:preferred}:undefined);
   recording=recorder;recordChunks=[];voiceAction='cancel';recStart=Date.now();
   recorder.addEventListener('dataavailable',e=>{if(e.data.size)recordChunks.push(e.data);});
   recorder.addEventListener('stop',async()=>{
     const shouldSend=voiceAction==='send';
     const parts=recordChunks.slice();
     const mime=recorder.mimeType||'audio/webm';
     stream.getTracks().forEach(t=>t.stop());
     if(audioStream===stream)audioStream=null;
     if(recording===recorder)recording=null;
     recordChunks=[];clearVoiceUI();
     if(!shouldSend)return; // cancelar descarta tudo sem enviar ao Supabase
     const ext=mime.includes('mp4')?'m4a':'webm';
     const blob=new File(parts,'audio-'+Date.now()+'.'+ext,{type:mime});
     $('file-status').classList.remove('hidden');$('file-status').textContent='Enviando áudio...';
     try{
       if(blob.size>64*1024*1024)throw Error('Gravação muito grande.');
       const uploaded=await uploadFile(blob);
       await sendMessage('',uploaded);
       $('file-status').textContent='Áudio enviado!';
       setTimeout(()=>$('file-status').classList.add('hidden'),2500);
     }catch(err){$('file-status').classList.add('hidden');banner('Erro ao enviar áudio: '+err.message);}
   },{once:true});
   recorder.start(500);
   $('record').classList.add('recording');$('record').innerHTML=MIC_ICON;
   $('record').setAttribute('aria-label','Gravando áudio. Use Cancelar ou Enviar áudio no painel.');
   $('record').title='Gravando áudio...';
   $('file-status').classList.add('hidden');
   $('voice-recorder').classList.remove('hidden');
   updateVoiceTime();voiceTimer=setInterval(updateVoiceTime,250);
 }catch(e){audioStream?.getTracks().forEach(t=>t.stop());audioStream=null;recording=null;clearVoiceUI();banner('Permita o uso do microfone no navegador para gravar áudio.');}
 finally{voiceBusy=false;}
});
$('group-avatar').addEventListener('click',()=>$('settings-panel').classList.toggle('hidden'));
$('change-photo').addEventListener('click',()=>$('group-photo-input').click());
$('group-photo-input').addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file||!file.type.startsWith('image/'))return;try{const media=await uploadFile(file,'avatar');const {error}=await db.from('chat_settings').update({group_photo_path:media.path,updated_at:new Date().toISOString()}).eq('id',1);if(error)throw error;await showGroupPhoto(media.path);$('settings-panel').classList.add('hidden');banner('');}catch(err){banner('Erro ao trocar a foto: '+err.message);}finally{e.target.value='';}});
let pushConfigured=false;
function b64ToUInt8(base64){const pad='='.repeat((4-base64.length%4)%4);const bin=atob((base64+pad).replace(/-/g,'+').replace(/_/g,'/'));return Uint8Array.from(bin,c=>c.charCodeAt(0));}
async function initPush(){if(!me||!('serviceWorker'in navigator)||!('PushManager'in window)||!('Notification'in window))return;try{const reg=await navigator.serviceWorker.ready;const sub=await reg.pushManager.getSubscription();if(sub&&window.NICK_NOAH_CONFIG?.vapidPublicKey){const {error}=await db.from('push_subscriptions').upsert({user_id:me.id,endpoint:sub.endpoint,subscription:sub.toJSON()},{onConflict:'endpoint'});if(!error)pushConfigured=true;}}catch(e){console.debug('Push indisponível',e);}}
$('notify').addEventListener('click',async()=>{if(!('Notification'in window)){banner('Este navegador não suporta notificações.');return;}const permission=await Notification.requestPermission();if(permission!=='granted'){banner('Permissão de notificação não concedida.');return;}
 if(!('PushManager'in window)||!('serviceWorker'in navigator)){banner('Avisos ativados apenas com o site aberto neste navegador.');return;}
 const key=window.NICK_NOAH_CONFIG?.vapidPublicKey;
 if(!key){banner('Para avisos com o app fechado, configure a chave Web Push no Supabase (veja o guia).');return;}
 try{const reg=await navigator.serviceWorker.ready;let sub=await reg.pushManager.getSubscription();if(sub){const existing=sub.options?.applicationServerKey;const expected=b64ToUInt8(key);if(existing && (new Uint8Array(existing).length!==expected.length||new Uint8Array(existing).some((x,i)=>x!==expected[i]))){await sub.unsubscribe();sub=null;}}if(!sub)sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:b64ToUInt8(key)});const {error}=await db.from('push_subscriptions').upsert({user_id:me.id,endpoint:sub.endpoint,subscription:sub.toJSON()},{onConflict:'endpoint'});if(error)throw error;pushConfigured=true;banner('Notificações push ativadas! Você pode receber avisos mesmo com o aplicativo fechado.');}catch(e){banner('Não foi possível ativar o push: '+e.message);}});

window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installEvent=e;});
$('install').addEventListener('click',async()=>{if(installEvent){installEvent.prompt();await installEvent.userChoice;installEvent=null;}else banner('Para instalar: no Chrome abra ⋮ → Instalar aplicativo ou Adicionar à tela inicial.');});
document.addEventListener('visibilitychange',()=>{if(!me)return;if(!document.hidden){lastChatInteraction=Date.now();document.title='Nick & Noah ♡';setPresence(true);loadMessages();loadPresence();}else setPresence(false);updateReadingState(true);});
window.addEventListener('focus',()=>{registerReadingInteraction();if(activelyReading())markRead();});
window.addEventListener('blur',()=>updateReadingState(true));
$('message-input').addEventListener('input',registerReadingInteraction);
$('messages').addEventListener('pointerdown',registerReadingInteraction,{passive:true});
window.addEventListener('pagehide',()=>{if(me){setPresence(false);if(navigator.sendBeacon){ /* O prazo de 25s do estado de leitura evita falsos positivos ao fechar a aba. */ }}});
if('serviceWorker'in navigator && location.protocol==='https:')navigator.serviceWorker.register('./sw.js').catch(console.warn);
loginView();
})();
