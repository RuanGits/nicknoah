# Nick & Noah — Em geral, basta publicar este ZIP

## O que mudou
- Seletor de emojis permanece aberto ao tocar em vários emojis.
- Fecha quando se digita texto comum na caixa de mensagem.
- Aba 🕘 Recentes: registra quantas vezes cada emoji foi escolhido e mostra os mais frequentes. Esse histórico começa nesta atualização, permanece no mesmo navegador/dispositivo e é separado por usuário. Não importa histórico antigo do WhatsApp nem sincroniza entre celular e Chromebook.
- Seta para ir ao final, com bolinha numerada para mensagens novas recebidas enquanto você está lendo mensagens antigas. Ao descer até o final, o contador zera.
- Corrigida a condição de envio das notificações: o remetente não precisa estar inscrito em push para a função ser chamada.

## Publicar
Substitua os arquivos da versão anterior pelos deste ZIP na Vercel. Nenhum SQL adicional é necessário para esses ajustes, desde que a migração `PUSH_E_EXCLUSAO.sql` já esteja aplicada.
No celular, feche o aplicativo completamente e abra novamente após publicar para receber a versão atualizada. Se usar instalação PWA, pode ser necessário remover/reinstalar quando o navegador mantiver cache antigo.

## Notificações: diagnóstico, não há garantia de entrega só com esta atualização
1. No celular que vai RECEBER (Noah), abra o aplicativo e toque no sino 🔔; aceite a permissão de notificações. Confirme que não aparece erro e que o dispositivo foi cadastrado em `push_subscriptions`. Para conferir sem expor endpoints: no SQL Editor do Supabase use `select count(*) from public.push_subscriptions;`. Esperado: pelo menos 1, se já ativou em algum aparelho.
2. No outro aparelho (Nick), envie uma mensagem nova. O app agora chama `nick-noah-push` mesmo se Nick não tiver ativado notificações.
3. No Supabase, abra Edge Functions > nick-noah-push > Invocations e Logs. Uma chamada bem-sucedida deve retornar `ok: true` e `delivered` maior que zero; `delivered: 0` costuma indicar ausência de inscrição do destinatário. Se houver erro 401/500, veja os logs; não desative a autenticação sem analisar.
4. Caso o app confirme a inscrição e a função apareça como entregue, confira notificações do sistema operacional, economia de bateria e versão do navegador. No iPhone, instale na tela inicial para Web Push.
5. A chave VAPID privada foi exposta em captura de tela anterior. Antes de usar definitivamente, gere novo PAR VAPID, substitua os segredos VAPID_PRIVATE_KEY e VAPID_PUBLIC_KEY no Supabase e substitua a chave pública `vapidPublicKey` em `config.js` pelo novo valor público. Depois publique novamente, toque no sino para recriar as inscrições. Nunca coloque a chave privada em arquivos do site ou em conversas.

## Atenção
Não foi possível testar o Supabase ou o celular real nesta execução. O som e a entrega de notificações em segundo plano dependem do navegador, dispositivo, permissão e da Edge Function.
