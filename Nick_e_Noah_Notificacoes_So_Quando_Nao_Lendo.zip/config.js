// Configuração pública do Supabase (não inserir chaves secretas aqui).
window.NICK_NOAH_CONFIG = {
  supabaseUrl: 'https://cwjnuglafznrdhbddxbo.supabase.co',
  supabaseKey: 'sb_publishable_nuCkdkwWrkqnuNfOK8YCAA_AfVQ9gb-'
  ,vapidPublicKey: 'BMFCEZeZQco5y57QLYCQopQru02lkv7IMkcoRNu3OGFF75VvNypot3ge7qhTTVZvbSJGAN9MnFOCXgMp8yoKM1I'
};
