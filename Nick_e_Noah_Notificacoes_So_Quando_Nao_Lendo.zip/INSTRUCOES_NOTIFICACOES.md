# Nick & Noah — Notificar somente quando não estiver lendo

**Regra para Nick e Noah**: sem notificação quando a pessoa está com a conversa aberta em primeiro plano, perto das mensagens atuais e interagiu com o chat recentemente. Estar apenas online não bloqueia notificações. Se estiver em outra aba, com o app fechado ou rolando mensagens antigas, a notificação deve chegar.

## Instalação (ambos os dispositivos)
1. Supabase > SQL Editor > New Query: execute `LEITURA_NOTIFICACOES.sql`. Não apaga mensagens.
2. Supabase > Edge Functions > `nick-noah-push`: atualize o código `index.ts` com o arquivo `supabase/functions/nick-noah-push/index.ts` deste ZIP e publique outra vez. Mantenha os secrets VAPID existentes (mas troque o par se ainda for o par exposto no print antigo).
3. Vercel: publique os arquivos do site na raiz deste ZIP (`index.html`, `app.js`, `sw.js` etc.). O servidor não precisa receber o arquivo SQL nem a pasta `supabase/`.
4. Abra o app nos dois dispositivos, atualize a página e permita notificações no sininho; o navegador pode precisar reinstalar a versão PWA para limpar o cache.
5. Teste com a conversa visível no final: não deve avisar. Teste lendo mensagens antigas ou deixando o aplicativo em segundo plano: deve avisar.

## Entenda os detalhes
- Para evitar confundir online com leitura, cada dispositivo informa temporariamente se a conversa está em primeiro plano e no final. O servidor desconsidera registros com mais de 25 segundos.
- A supressão de Web Push acontece no servidor; o som e os avisos do navegador também são suprimidos quando o usuário está lendo. A checagem de leitura é feita quando o remetente envia a mensagem.
- A presença é aproximada: se a rede cair, a última atualização pode persistir por até 25 segundos.
- Notificações push ainda dependem de inscrição válida, permissões do sistema e suporte do aparelho; isso não conserta problemas preexistentes de entrega ou de chaves VAPID.
- O navegador não tem como saber literalmente se seus olhos estão lendo: usa foco, visibilidade, rolagem e interação.
- Não exponha VAPID_PRIVATE_KEY no site nem envie a chave por mensagens.
