// Nick & Noah — PWA e notificações Web Push.
const CACHE='nick-noah-shell-reading-v9';
const ASSETS=['./','./index.html','./app.js','./emojis.js','./config.js','./manifest.webmanifest','./favicon.png','./icon-192.png','./icon-512.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(event.request.method!=='GET'||url.origin!==self.location.origin)return;if(url.pathname.endsWith('/config.js')){event.respondWith(fetch(event.request));return;}event.respondWith(fetch(event.request).catch(()=>caches.match(event.request)))});
self.addEventListener('push',event=>{
 let payload={};try{payload=event.data?.json()||{};}catch{payload={};}
 const title=payload.title||'Nick & Noah 💗';
 const options={body:payload.body||'Uma nova mensagem chegou!',icon:'./icon-192.png',badge:'./favicon.png',tag:payload.tag||'nick-noah-chat',renotify:true,vibrate:[120,60,120],data:{url:'./'}};
 event.waitUntil((async()=>{
  // Uma notificação do sistema aparece mesmo com o app fechado, se o SO permitir.
  await self.registration.showNotification(title,options);
  if(self.navigator?.setAppBadge)await self.navigator.setAppBadge().catch(()=>{});
 })());
});
self.addEventListener('notificationclick',event=>{
 event.notification.close();
 event.waitUntil((async()=>{const clients=await self.clients.matchAll({type:'window',includeUncontrolled:true});for(const c of clients){if('focus'in c){await c.focus();c.postMessage({type:'nick-noah-open'});return;}}await self.clients.openWindow('./');})());
});
